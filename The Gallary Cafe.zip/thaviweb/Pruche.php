<?php
// Database connection details
$host = "127.0.0.1"; // MySQL server address
$username = "root"; // MySQL username
$password = ""; // MySQL password
$database = "resturant"; // Database name

// Establish a connection to the database
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $phonenumber = mysqli_real_escape_string($conn, $_POST["phonenumber"]);
    $categoryselect = mysqli_real_escape_string($conn, $_POST["categoryselect"]);
    $personcount = mysqli_real_escape_string($conn, $_POST["personcount"]);
    $cart = mysqli_real_escape_string($conn, $_POST["carttotal"]);
    $cartitems = mysqli_real_escape_string($conn, $_POST["cartitems"]);

    // Get current date and time
    $order_date = date('Y-m-d');
    $order_time = date('H:i:s');

    // SQL query to insert data into the database
    $sql = "INSERT INTO orderdetails (Username, Phonenumber, Categoryselect,personcount, Carttotal, Cartitems, order_date, order_time) VALUES ('$username', '$phonenumber', '$categoryselect','$personcount', '$cart', '$cartitems', '$order_date', '$order_time')";

    if ($conn->query($sql) === TRUE) {
        // Redirect the user to another page here if registration is successful
        echo "<script>alert('Order successfully Pasted ');</script>";
        header("Location: order.php");
        exit(); // Make sure to exit after redirection
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Perchues Menu</title>
  <link rel="stylesheet" href="Pruche.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <style>

/* Cart styles */
#cart {
    width: 45%;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

#cart h2 {
    margin-top: 0;
    text-align: center;
}

#cart-items {
    list-style: none;
    padding: 0;
    margin: 20px 0;
}

#cart-items li {
    background-color: #fff;
    padding: 10px;
    margin: 10px 0;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

#cart-items li button {
    padding: 5px 10px;
    background-color: #ff4444;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

#cart-items li button:hover {
    background-color: #ff0000;
}

#cart-total {
    font-size: 1.2em;
    margin: 10px 0;
    text-align: right;
}

form {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.form-group {
    margin-bottom: 15px;
    width: 100%;
}

.form-group label {
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group input, 
.form-group select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 100%;
}

button[type="submit"] {
    padding: 10px 20px;
    width: 100%;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    align-self: center;
}

button[type="submit"]:hover {
    background-color: #45a049;
}
  </style>
</head>
<body> 
    <header class="header">
        <a href="#" class="logo">The Gallery Chef</a>
        <nav class="navigation">
            <a href="Homepage.html">Home</a>
            <a href="#" class="active">Product Menu</a>
        </nav>
    </header>
    <div class="image">
        <div class="home">
            <div class="Homecontent">
                <h1>The Gallery Chef</h1>
                <h5>For Foodie</h5>
                <p>"Welcome to The Gallery Café, a beloved dining destination located in the heart of Colombo. We are dedicated to enhancing your culinary experience with the latest technological advancements. Our new interactive web-based application is designed to seamlessly integrate with our operations, allowing you to make reservations, place orders, and stay connected with us like never before. Our commitment to excellence extends beyond our delectable cuisine and inviting atmosphere; our professionally designed website reflects our brand's essence and makes your experience with The Gallery Café truly exceptional. Join us online to explore our menu, book a table, or simply learn more about what makes The Gallery Café a cherished spot for food lovers."</p>
            </div>
        </div>
        <div class="social1">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="https://wa.me/94755317941"><i class="fab fa-whatsapp"></i></a>
        </div>
        <span class="imgaehome"></span>
    </div>
    <button onclick="topFunction()" id="myBtn" title="Go to top"><a href="https://wa.me/94755317941"><i class="fab fa-whatsapp"></i></a></button>
    <div class="Purch">
        <div class="pu2">
            <div id="product-search">
                <input type="text" id="search-input" placeholder="Search for products">
                <select id="category-select">
                    <option value="all">All cuisine</option>
                    <option value="Indian">Indian</option>
                    <option value="Chinese">Chinese</option>
                    <option value="Italian">Italian</option>
                    <option value="Srilankan">Srilankan</option>
                </select>
                <button id="search-button">Search</button>
            </div>
            <div id="product-list">
                <!-- Product results will be displayed here -->
            </div>
            <div id="cart">
                <h2>Shopping Cart</h2>
                <ul id="cart-items">
                    <!-- Cart items will be displayed here -->
                </ul>
                <p id="cart-total">Total: $0.00</p>
                <form action="" method="post"> <!-- Specify the PHP file to handle the form data -->
                    <input type="hidden" id="cart-total-input" name="carttotal">
                    <input type="hidden" id="cart-total-items" name="cartitems">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="phonenumber">PhoneNumber:</label>
                        <input type="text" id="phonenumber" name="phonenumber" required>
                    </div>
                    <div class="form-group">
                        <label for="personcount">Person Count:</label>
                        <input type="number" id="personcount" name="personcount" required>
                    </div>
                    <div>
                    <div class="form-group">
                    <label for="phonenumber">Parking Selection:</label>
                        <select id="categoryselect" name="categoryselect">
                            <option value="all">Parking</option>
                            <option value="two">Bike</option>
                            <option value="four">Car</option>
                        </select>
</div>
                    </div>
                    <button type="submit" >Pay</button>
                </form>
            </div>
        </div>
    </div>
    <script src="Pruche.js"></script>
    <script>
        // Ensure the cart total is set before form submission
        document.querySelector('form').addEventListener('submit', function() {
            var cartTotal = document.getElementById('cart-total').innerText.replace('Total: $', '');
            var cartitems = document.getElementById('cart-items').innerText.replace('Items: W', '');
            document.getElementById('cart-total-input').value = cartTotal;
            document.getElementById('cart-total-items').value = cartitems;
            
        });
    </script>
</body>
</html>
