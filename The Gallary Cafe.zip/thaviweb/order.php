<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            align-items:center;
            background:url(./food/create-realistic-food-photographs.png);
            text-align:center;
        }
        h1{
            font-size:32px;
           color:white;
        }
        p{
            font-size:32px;
           color:white;
        }
        a{
            font-size:32px;
            color:white;
        }

    </style>
</head>
<body>
    <div>
    <h1>Your Order will Come Soon</h1>
    <p>Enjoy your Meals </p>
    <p>If you change your Order Plaese contact us Quickly</p>

    <a href="Homepage.html"> Back</a>
    </div>
   
</body>
</html>