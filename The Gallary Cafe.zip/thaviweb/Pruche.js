// Sample product data (in a real application, this would come from a server)
const products = [
    { id: 1, name: "Chow Mein", category: "Chinese", price: 500, image: "./food/ch5.jpg" },
    { id: 2, name: "Kun Pao Chicken", category: "Chinese", price: 200, image: "./food/ch.jpg" },
    { id: 3, name: "Hot and sour Soup", category: "Chinese", price: 150, image: "./food/ch1.webp" },
    { id: 4, name: "Sprin Rolls", category: "Chinese", price: 300, image: "./food/ch2.jpg" },
    { id: 5, name: "Dim Sum", category: "Chinese", price: 400, image: "./food/ch4.jpg" },
];

const searchInput = document.getElementById('search-input');
const categorySelect = document.getElementById('category-select');
const searchButton = document.getElementById('search-button');
const productList = document.getElementById('product-list');
const cartItems = document.getElementById('cart-items');
const cartTotal = document.getElementById('cart-total');

// Initialize cart
const cart = [];

// Function to display products
function displayProducts(productArray) {
    productList.innerHTML = '';
    productArray.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product');
        productItem.innerHTML = `
            <h3>${product.name}</h3>
            <p>Category: ${product.category}</p>
            <p>Price: ${product.price}</p>
            <img src="${product.image}" alt="${product.name}" style="width: 300px; height: 150px; ">
            <button data-id="${product.id}" class="add-to-cart">Add to Cart</button>
        `;
        productList.appendChild(productItem);
    });
}

// Function to add a product to the cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCartDisplay();
    }
}

// Function to update the cart display and total
function updateCartDisplay() {
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach((item, index) => {
        const cartItem = document.createElement('li');
        cartItem.innerHTML = `${item.name} - ${item.price} <button onclick="removeFromCart(${index})">Remove</button>`;
        cartItems.appendChild(cartItem);
        total += item.price;
    });
    cartTotal.textContent = `Total: ${total.toFixed(2)}`;
}

// Function to remove a product from the cart
function removeFromCart(index) {
    const item = cart[index];
    cart.splice(index, 1);
    updateCartDisplay();
}

// Event listener for the search button
searchButton.addEventListener('click', () => {
    const searchTerm = searchInput.value.toLowerCase();
    const selectedCategory = categorySelect.value;
    const filteredProducts = products.filter(product => {
        const matchName = product.name.toLowerCase().includes(searchTerm);
        const matchCategory = selectedCategory === 'all' || product.category === selectedCategory;
        return matchName && matchCategory;
    });
    displayProducts(filteredProducts);
});

// Event delegation for "Add to Cart" button clicks
productList.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const productId = parseInt(e.target.getAttribute('data-id'));
        addToCart(productId);
    }
});

// Initial product display
displayProducts(products);


//scroll

let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}
