<?php
// Database connection details
$host = "127.0.0.1"; // MySQL server address
$username = "root"; // MySQL username
$password = ""; // MySQL password
$database = "resturant"; // Database name

// Establish a connection to the database
$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $age = mysqli_real_escape_string($conn, $_POST["age"]);
    $phonenumber = mysqli_real_escape_string($conn, $_POST["phonenumber"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    

    // SQL query to insert data into the database
    $sql = "INSERT INTO userdetail (Username, Email, Age, Phonenumber, Password) VALUES ('$username', '$email', '$age', '$phonenumber', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
        // You can redirect the user to another page here if registration is successful
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
